function printSegment(segment)
    hold on
    plot(segment(:,1),segment(:,2),'r','LineWidth',1.5)
    hold off
end

